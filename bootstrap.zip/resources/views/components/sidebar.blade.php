<div class="position-absolute bg-primary" style="width: 20rem; left:0; height:100vh; z-index: 100;">
    <div class="contend-wrapper">
        <h1 class="text-white ms-4 mt-5">Latis Education</h1>
        <div class="nav-content mt-2 flex flex-col">
            <ul style="list-style-type: none">
                <li>
                    <a href="/" class="text-white ms-4 "><p>Siswa</p></a>
                </li>
                <li>
                    <a href="/" class="text-white ms-4"><p>Profile</p></a>
                </li>
            </ul>
        </div>
    </div>
</div>
